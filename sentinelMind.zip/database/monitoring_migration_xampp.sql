-- SentinelMind Monitoring Module Migration
-- Run in XAMPP phpMyAdmin: select sentinelmind_db > SQL > paste this file.
-- Back up the database before running. This migration preserves existing data.

USE sentinelmind_db;

CREATE TABLE IF NOT EXISTS user_sessions (
  session_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  session_token_hash CHAR(64) NOT NULL UNIQUE,
  user_id INT NOT NULL,
  login_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_seen_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  logout_at DATETIME NULL,
  ip_address VARCHAR(45) NULL,
  user_agent VARCHAR(500) NULL,
  status ENUM('ACTIVE','CLOSED','EXPIRED') NOT NULL DEFAULT 'ACTIVE',
  INDEX idx_sessions_user_login (user_id, login_at),
  INDEX idx_sessions_status_seen (status, last_seen_at),
  CONSTRAINT fk_sessions_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS user_activity_logs (
  activity_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  user_id INT NOT NULL,
  session_id BIGINT NULL,
  page_path VARCHAR(255) NOT NULL,
  action_type VARCHAR(80) NOT NULL DEFAULT 'PAGE_VIEW',
  details VARCHAR(1000) NULL,
  duration_seconds INT NOT NULL DEFAULT 0,
  ip_address VARCHAR(45) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_activity_user_time (user_id, created_at),
  INDEX idx_activity_page_time (page_path, created_at),
  CONSTRAINT fk_activity_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
  CONSTRAINT fk_activity_session FOREIGN KEY (session_id) REFERENCES user_sessions(session_id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS user_heartbeats (
  heartbeat_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  user_id INT NOT NULL,
  session_id BIGINT NOT NULL,
  last_seen_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_heartbeat_session (session_id),
  INDEX idx_heartbeat_seen (last_seen_at),
  CONSTRAINT fk_heartbeat_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
  CONSTRAINT fk_heartbeat_session FOREIGN KEY (session_id) REFERENCES user_sessions(session_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS permissions (
  permission_id INT PRIMARY KEY AUTO_INCREMENT,
  permission_key VARCHAR(100) NOT NULL UNIQUE,
  description VARCHAR(255) NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS role_permissions (
  role_id INT NOT NULL,
  permission_id INT NOT NULL,
  PRIMARY KEY (role_id, permission_id),
  CONSTRAINT fk_roleperm_role FOREIGN KEY (role_id) REFERENCES roles(role_id) ON DELETE CASCADE,
  CONSTRAINT fk_roleperm_permission FOREIGN KEY (permission_id) REFERENCES permissions(permission_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS user_permissions (
  user_id INT NOT NULL,
  permission_id INT NOT NULL,
  granted BOOLEAN NOT NULL DEFAULT TRUE,
  granted_by INT NULL,
  granted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, permission_id),
  CONSTRAINT fk_userperm_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
  CONSTRAINT fk_userperm_permission FOREIGN KEY (permission_id) REFERENCES permissions(permission_id) ON DELETE CASCADE,
  CONSTRAINT fk_userperm_grantor FOREIGN KEY (granted_by) REFERENCES users(user_id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS employee_profiles (
  user_id INT PRIMARY KEY,
  employee_code VARCHAR(40) NULL UNIQUE,
  department VARCHAR(100) NULL,
  designation VARCHAR(100) NULL,
  manager_user_id INT NULL,
  joined_on DATE NULL,
  CONSTRAINT fk_employee_profile_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
  CONSTRAINT fk_employee_profile_manager FOREIGN KEY (manager_user_id) REFERENCES users(user_id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS tasks (
  task_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(180) NOT NULL,
  description TEXT NULL,
  priority ENUM('LOW','MEDIUM','HIGH','CRITICAL') NOT NULL DEFAULT 'MEDIUM',
  status ENUM('OPEN','IN_PROGRESS','COMPLETED','CANCELLED') NOT NULL DEFAULT 'OPEN',
  due_at DATETIME NULL,
  created_by INT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_tasks_creator FOREIGN KEY (created_by) REFERENCES users(user_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS task_assignments (
  task_assignment_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  task_id BIGINT NOT NULL,
  assigned_user_id INT NOT NULL,
  assigned_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  completed_at DATETIME NULL,
  UNIQUE KEY uq_task_user (task_id, assigned_user_id),
  CONSTRAINT fk_taskassign_task FOREIGN KEY (task_id) REFERENCES tasks(task_id) ON DELETE CASCADE,
  CONSTRAINT fk_taskassign_user FOREIGN KEY (assigned_user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS notifications (
  notification_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  user_id INT NOT NULL,
  title VARCHAR(180) NOT NULL,
  message VARCHAR(1000) NOT NULL,
  is_read BOOLEAN NOT NULL DEFAULT FALSE,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_notification_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
  INDEX idx_notifications_user_read (user_id, is_read, created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS security_alerts (
  alert_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  user_id INT NULL,
  alert_type VARCHAR(100) NOT NULL,
  severity ENUM('LOW','MEDIUM','HIGH','CRITICAL') NOT NULL DEFAULT 'MEDIUM',
  description VARCHAR(1000) NOT NULL,
  status ENUM('OPEN','REVIEWED','RESOLVED') NOT NULL DEFAULT 'OPEN',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  reviewed_by INT NULL,
  reviewed_at DATETIME NULL,
  CONSTRAINT fk_alert_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL,
  CONSTRAINT fk_alert_reviewer FOREIGN KEY (reviewed_by) REFERENCES users(user_id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS system_backups (
  backup_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  backup_name VARCHAR(255) NOT NULL,
  backup_path VARCHAR(500) NULL,
  backup_status ENUM('PENDING','COMPLETED','FAILED') NOT NULL DEFAULT 'PENDING',
  created_by INT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  notes VARCHAR(1000) NULL,
  CONSTRAINT fk_backup_user FOREIGN KEY (created_by) REFERENCES users(user_id) ON DELETE SET NULL
) ENGINE=InnoDB;

INSERT IGNORE INTO permissions(permission_key, description) VALUES
('DASHBOARD_VIEW','View the application dashboard'),
('INCIDENT_VIEW','View incidents'),
('INCIDENT_MANAGE','Create and update incidents'),
('THREAT_VIEW','View threat records'),
('THREAT_MANAGE','Create, update and delete threat records'),
('EVIDENCE_MANAGE','Manage incident evidence'),
('ASSIGNMENT_MANAGE','Manage incident assignments'),
('SCAN_MANAGE','Submit and view security scan requests'),
('ADMIN_MONITORING_VIEW','View centralized employee monitoring'),
('USER_MANAGE','Manage user accounts and roles'),
('AUDIT_VIEW','View audit records'),
('REPORT_EXPORT','Export reports');

INSERT IGNORE INTO role_permissions(role_id, permission_id)
SELECT r.role_id, p.permission_id FROM roles r JOIN permissions p
WHERE r.role_name='ADMIN';

INSERT IGNORE INTO role_permissions(role_id, permission_id)
SELECT r.role_id, p.permission_id FROM roles r JOIN permissions p
WHERE r.role_name='ANALYST' AND p.permission_key IN
('DASHBOARD_VIEW','INCIDENT_VIEW','INCIDENT_MANAGE','THREAT_VIEW','EVIDENCE_MANAGE','ASSIGNMENT_MANAGE','SCAN_MANAGE');

INSERT IGNORE INTO role_permissions(role_id, permission_id)
SELECT r.role_id, p.permission_id FROM roles r JOIN permissions p
WHERE r.role_name='USER' AND p.permission_key IN
('DASHBOARD_VIEW','INCIDENT_VIEW','INCIDENT_MANAGE','THREAT_VIEW','SCAN_MANAGE');

-- A monitoring view. A user is considered recently active when a heartbeat
-- has been received within the last 90 seconds. This is an estimate, not proof
-- that the person is physically at the computer.
CREATE OR REPLACE VIEW v_user_presence AS
SELECT u.user_id, u.full_name, u.email, r.role_name,
       s.session_id, s.login_at, s.last_seen_at,
       CASE
         WHEN s.status='ACTIVE' AND s.last_seen_at >= DATE_SUB(NOW(), INTERVAL 90 SECOND) THEN 'ONLINE'
         WHEN s.status='ACTIVE' THEN 'IDLE_OR_STALE'
         ELSE 'OFFLINE'
       END AS presence_status,
       s.ip_address, s.user_agent
FROM users u
JOIN roles r ON r.role_id=u.role_id
LEFT JOIN user_sessions s ON s.user_id=u.user_id AND s.status='ACTIVE'
 AND s.session_id=(SELECT MAX(s2.session_id) FROM user_sessions s2 WHERE s2.user_id=u.user_id AND s2.status='ACTIVE');
