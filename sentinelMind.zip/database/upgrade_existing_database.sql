USE sentinelmind_db;
-- BACK UP YOUR DATABASE BEFORE RUNNING THIS MIGRATION.
-- Safe to run repeatedly on MySQL 8: only missing columns are added.
SET @schema_name = DATABASE();
SET @sql = IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@schema_name AND TABLE_NAME='users' AND COLUMN_NAME='failed_login_attempts')=0,
 'ALTER TABLE users ADD COLUMN failed_login_attempts INT NOT NULL DEFAULT 0', 'SELECT 1'); PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @sql = IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@schema_name AND TABLE_NAME='users' AND COLUMN_NAME='last_login')=0,
 'ALTER TABLE users ADD COLUMN last_login TIMESTAMP NULL', 'SELECT 1'); PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @sql = IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@schema_name AND TABLE_NAME='users' AND COLUMN_NAME='updated_at')=0,
 'ALTER TABLE users ADD COLUMN updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP', 'SELECT 1'); PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
INSERT IGNORE INTO roles(role_name) VALUES ('USER');
UPDATE users u JOIN roles old_role ON old_role.role_id=u.role_id JOIN roles user_role ON user_role.role_name='USER' SET u.role_id=user_role.role_id WHERE old_role.role_name='EMPLOYEE';
CREATE TABLE IF NOT EXISTS access_codes (
 access_code_id INT PRIMARY KEY AUTO_INCREMENT, code_hash CHAR(64) NOT NULL UNIQUE, role_id INT NOT NULL,
 code_label VARCHAR(100) NOT NULL, max_uses INT NOT NULL DEFAULT 1, used_count INT NOT NULL DEFAULT 0,
 expires_at DATETIME NULL, is_active BOOLEAN NOT NULL DEFAULT TRUE, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_access_codes_role FOREIGN KEY (role_id) REFERENCES roles(role_id));
CREATE TABLE IF NOT EXISTS audit_logs (
 audit_id BIGINT PRIMARY KEY AUTO_INCREMENT, user_id INT NULL, action VARCHAR(100) NOT NULL,
 entity_type VARCHAR(80) NOT NULL, entity_id VARCHAR(80) NULL, details VARCHAR(1000) NULL,
 ip_address VARCHAR(45) NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_audit_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL);
-- Registration access code seeding removed from public template.
-- Create long random registration codes locally and store their SHA-256 hashes.

-- Registration access code seeding removed from public template.
-- Create long random registration codes locally and store their SHA-256 hashes.

-- Registration access code seeding removed from public template.
-- Create long random registration codes locally and store their SHA-256 hashes.

