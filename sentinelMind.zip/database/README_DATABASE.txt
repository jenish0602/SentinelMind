1. Import the appropriate schema in a local MySQL-compatible database.
2. Configure SM_DB_URL, SM_DB_USER, SM_DB_PASSWORD for JDBC.
3. Hibernate has separate connection settings; review before use.
4. Create role-specific registration codes locally. Do not commit the raw codes.
5. Never publish database dumps with real user data.
