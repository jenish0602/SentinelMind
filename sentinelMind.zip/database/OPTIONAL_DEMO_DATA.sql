-- Optional demonstration records for existing sentinelmind_db. No tables are dropped.
-- Run only once on a development database if you want example data.
USE sentinelmind_db;
INSERT INTO threats(threat_name,threat_type,description,source_ip,risk_level,threat_status)
SELECT 'Repeated failed login attempts','AUTHENTICATION','Example: multiple failed sign-in attempts from one address','192.0.2.10','HIGH','DETECTED'
WHERE NOT EXISTS (SELECT 1 FROM threats WHERE threat_name='Repeated failed login attempts');
INSERT INTO threats(threat_name,threat_type,description,source_ip,risk_level,threat_status)
SELECT 'Suspicious URL indicator','PHISHING','Example: potentially deceptive link reported by an employee',NULL,'MEDIUM','DETECTED'
WHERE NOT EXISTS (SELECT 1 FROM threats WHERE threat_name='Suspicious URL indicator');
INSERT INTO incidents(title,description,incident_type,severity,status,reported_by)
SELECT 'Example: suspicious authentication activity','Demonstration incident for workflow testing','AUTHENTICATION','HIGH','OPEN',(SELECT MIN(user_id) FROM users)
WHERE NOT EXISTS (SELECT 1 FROM incidents WHERE title='Example: suspicious authentication activity');
