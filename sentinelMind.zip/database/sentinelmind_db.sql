CREATE DATABASE IF NOT EXISTS sentinelmind_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sentinelmind_db;

CREATE TABLE IF NOT EXISTS roles (
  role_id INT PRIMARY KEY AUTO_INCREMENT,
  role_name VARCHAR(40) NOT NULL UNIQUE
);
INSERT IGNORE INTO roles(role_id, role_name) VALUES (1,'ADMIN'),(2,'ANALYST');

CREATE TABLE IF NOT EXISTS users (
  user_id INT PRIMARY KEY AUTO_INCREMENT,
  role_id INT NOT NULL,
  full_name VARCHAR(120) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  status ENUM('ACTIVE','DISABLED') NOT NULL DEFAULT 'ACTIVE',
  failed_login_attempts INT NOT NULL DEFAULT 0,
  last_login TIMESTAMP NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_users_role FOREIGN KEY (role_id) REFERENCES roles(role_id)
);

-- Normalize the standard role for both fresh installs and older starter databases.
INSERT IGNORE INTO roles(role_name) VALUES ('USER');
UPDATE users u JOIN roles old_role ON old_role.role_id=u.role_id JOIN roles user_role ON user_role.role_name='USER' SET u.role_id=user_role.role_id WHERE old_role.role_name='EMPLOYEE';

CREATE TABLE IF NOT EXISTS incidents (
  incident_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(180) NOT NULL,
  description TEXT NOT NULL,
  severity ENUM('LOW','MEDIUM','HIGH','CRITICAL') NOT NULL DEFAULT 'MEDIUM',
  status ENUM('OPEN','IN_PROGRESS','RESOLVED','CLOSED') NOT NULL DEFAULT 'OPEN',
  reported_by INT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_incident_reporter FOREIGN KEY (reported_by) REFERENCES users(user_id)
);

CREATE TABLE IF NOT EXISTS threats (
  threat_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  threat_name VARCHAR(160) NOT NULL,
  category VARCHAR(80) NOT NULL,
  risk_level ENUM('LOW','MEDIUM','HIGH','CRITICAL') NOT NULL,
  mitigation TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS incident_evidence (
  evidence_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  incident_id BIGINT NOT NULL,
  file_name VARCHAR(255) NOT NULL,
  storage_path VARCHAR(500) NOT NULL,
  uploaded_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_evidence_incident FOREIGN KEY (incident_id) REFERENCES incidents(incident_id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS incident_assignments (
  assignment_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  incident_id BIGINT NOT NULL,
  assigned_user_id INT NOT NULL,
  assigned_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_assignment_incident FOREIGN KEY (incident_id) REFERENCES incidents(incident_id) ON DELETE CASCADE,
  CONSTRAINT fk_assignment_user FOREIGN KEY (assigned_user_id) REFERENCES users(user_id)
);
CREATE TABLE IF NOT EXISTS security_scans (
  scan_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  user_id INT NOT NULL,
  scan_type VARCHAR(80) NOT NULL,
  target VARCHAR(255) NOT NULL,
  scan_status ENUM('PENDING','RUNNING','COMPLETED','FAILED') NOT NULL DEFAULT 'PENDING',
  started_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  completed_at TIMESTAMP NULL,
  CONSTRAINT fk_scan_user FOREIGN KEY (user_id) REFERENCES users(user_id)
);
CREATE TABLE IF NOT EXISTS access_codes (
  access_code_id INT PRIMARY KEY AUTO_INCREMENT,
  code_hash CHAR(64) NOT NULL UNIQUE,
  role_id INT NOT NULL,
  code_label VARCHAR(100) NOT NULL,
  max_uses INT NOT NULL DEFAULT 1,
  used_count INT NOT NULL DEFAULT 0,
  expires_at DATETIME NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_access_codes_role FOREIGN KEY (role_id) REFERENCES roles(role_id)
);
CREATE TABLE IF NOT EXISTS audit_logs (
  audit_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  user_id INT NULL,
  action VARCHAR(100) NOT NULL,
  entity_type VARCHAR(80) NOT NULL,
  entity_id VARCHAR(80) NULL,
  details VARCHAR(1000) NULL,
  ip_address VARCHAR(45) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_audit_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL
);

-- Registration access code seeding removed from public template.
-- Create long random registration codes locally and store their SHA-256 hashes.

-- Registration access code seeding removed from public template.
-- Create long random registration codes locally and store their SHA-256 hashes.

-- Registration access code seeding removed from public template.
-- Create long random registration codes locally and store their SHA-256 hashes.


INSERT INTO threats(threat_name,category,risk_level,mitigation)
SELECT 'Credential phishing','Social Engineering','HIGH','Verify sender, inspect links, report suspicious messages'
WHERE NOT EXISTS (SELECT 1 FROM threats WHERE threat_name='Credential phishing');
INSERT INTO threats(threat_name,category,risk_level,mitigation)
SELECT 'Weak password reuse','Identity Risk','HIGH','Use unique passwords and enable multi-factor authentication'
WHERE NOT EXISTS (SELECT 1 FROM threats WHERE threat_name='Weak password reuse');

-- Existing-install migration notes (run only if the column is missing):
-- ALTER TABLE users ADD COLUMN failed_login_attempts INT NOT NULL DEFAULT 0;
-- ALTER TABLE users ADD COLUMN last_login TIMESTAMP NULL;
-- ALTER TABLE users ADD COLUMN updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
-- If an older database has EMPLOYEE instead of USER: UPDATE roles SET role_name='USER' WHERE role_name='EMPLOYEE';
