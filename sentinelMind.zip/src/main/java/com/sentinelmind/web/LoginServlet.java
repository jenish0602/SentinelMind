package com.sentinelmind.web;

import com.sentinelmind.config.DBConnection;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.mindrot.jbcrypt.BCrypt;
import com.sentinelmind.dao.MonitoringDAO;
import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        request.getRequestDispatcher("/login.jsp")
               .forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        if (email == null || password == null ||
            email.isBlank() || password.isEmpty()) {

            request.setAttribute("error", "Enter your email and password.");
            request.getRequestDispatcher("/login.jsp").forward(request, response);
            return;
        }

        email = email.trim().toLowerCase();

        String sql =
                "SELECT u.user_id, u.full_name, u.email, u.password_hash, " +
                "u.role_id, u.status, r.role_name " +
                "FROM users u " +
                "JOIN roles r ON u.role_id = r.role_id " +
                "WHERE u.email = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, email);

            try (ResultSet rs = ps.executeQuery()) {

                if (!rs.next()) {
                    showLoginError(request, response);
                    return;
                }

                String status = rs.getString("status");
                String storedHash = rs.getString("password_hash");

                if (!"ACTIVE".equalsIgnoreCase(status) ||
                    storedHash == null ||
                    !storedHash.startsWith("$2")) {

                    showLoginError(request, response);
                    return;
                }

                boolean passwordMatches;

                try {
                    passwordMatches = BCrypt.checkpw(password, storedHash);
                } catch (IllegalArgumentException ex) {
                    passwordMatches = false;
                }

                if (!passwordMatches) {
                    showLoginError(request, response);
                    return;
                }

                int userId = rs.getInt("user_id");
                String fullName = rs.getString("full_name");
                int roleId = rs.getInt("role_id");
                String roleName = rs.getString("role_name");

                HttpSession oldSession = request.getSession(false);

                if (oldSession != null) {
                    oldSession.invalidate();
                }

                HttpSession session = request.getSession(true);
                request.changeSessionId();

                session.setAttribute("userId", userId);
                session.setAttribute("fullName", fullName);
                session.setAttribute("email", email);
                session.setAttribute("roleId", roleId);
                session.setAttribute("roleName", roleName);

                try {
                    String rawToken = session.getId();
                    String tokenHash = java.util.HexFormat.of().formatHex(
                        MessageDigest.getInstance("SHA-256").digest(rawToken.getBytes(StandardCharsets.UTF_8)));
                    long monitorSessionId = new MonitoringDAO().startSession(
                        userId, tokenHash, request.getRemoteAddr(), request.getHeader("User-Agent"));
                    session.setAttribute("monitorSessionId", monitorSessionId);
                } catch (Exception trackingError) {
                    getServletContext().log("Could not start monitoring session", trackingError);
                }

                try (PreparedStatement update = con.prepareStatement(
                        "UPDATE users SET last_login = CURRENT_TIMESTAMP, " +
                        "failed_login_attempts = 0, updated_at = CURRENT_TIMESTAMP " +
                        "WHERE user_id = ?")) {

                    update.setInt(1, userId);
                    update.executeUpdate();
                }

                response.sendRedirect(request.getContextPath() + "/dashboard");
            }

        } catch (SQLException e) {
            throw new ServletException("Login database operation failed.", e);
        }
    }

    private void showLoginError(HttpServletRequest request,
                                HttpServletResponse response)
            throws ServletException, IOException {

        request.setAttribute("error",
                "Invalid email or password, or the account is inactive.");

        request.getRequestDispatcher("/login.jsp")
               .forward(request, response);
    }
}
