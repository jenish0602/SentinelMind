package com.sentinelmind.web;

import com.sentinelmind.dao.MonitoringDAO;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import jakarta.servlet.*;
import java.io.IOException;

@WebServlet("/logout")
public class LogoutServlet extends HttpServlet {
    @Override protected void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException { logout(req,res); }
    @Override protected void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException { logout(req,res); }
    private void logout(HttpServletRequest req,HttpServletResponse res)throws IOException {
        HttpSession s=req.getSession(false);
        if(s!=null) {
            Object id=s.getAttribute("monitorSessionId");
            if(id instanceof Long) {
                try { new MonitoringDAO().closeSession((Long)id); }
                catch(Exception e) { getServletContext().log("Could not close monitoring session",e); }
            }
            s.invalidate();
        }
        res.setHeader("Cache-Control","no-store, no-cache, must-revalidate");
        res.setHeader("Pragma","no-cache");
        res.sendRedirect(req.getContextPath()+"/login.jsp?loggedOut=1");
    }
}
