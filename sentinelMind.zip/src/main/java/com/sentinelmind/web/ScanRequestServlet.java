package com.sentinelmind.web;
import com.sentinelmind.config.DBConnection;
import com.sentinelmind.dao.AuditDAO;
import jakarta.servlet.*;import jakarta.servlet.annotation.WebServlet;import jakarta.servlet.http.*;
import java.io.IOException;import java.sql.*;import java.net.URI;import java.util.Set;
@WebServlet("/scan-request") public class ScanRequestServlet extends HttpServlet {
 @Override protected void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException {
 String type=req.getParameter("scanType"),target=req.getParameter("target");
 if(type==null||!Set.of("URL_CHECK","IP_REPUTATION","FILE_HASH","LOG_ANALYSIS").contains(type)||target==null||target.isBlank()||target.length()>500){res.sendError(400,"Invalid scan request");return;}
 target=target.trim();String result;String status="COMPLETED";
 switch(type){
 case "URL_CHECK" -> {try{URI u=new URI(target);if(!Set.of("http","https").contains(u.getScheme())||u.getHost()==null)throw new Exception();result="Offline URL validation: valid URL syntax; scheme="+u.getScheme()+"; host="+u.getHost()+". No remote reputation or live website check performed.";}catch(Exception e){result="Invalid HTTP(S) URL syntax";status="FAILED";}}
 case "IP_REPUTATION" -> {if(target.matches("(?:[0-9]{1,3}\\.){3}[0-9]{1,3}")){String[] parts=target.split("\\.");boolean valid=true;for(String part:parts)if(Integer.parseInt(part)>255)valid=false;result=valid?"IPv4 syntax valid. No external reputation feed queried.":"Invalid IPv4 address";if(!valid)status="FAILED";}else{result="Expected an IPv4 address; no external reputation feed queried.";status="FAILED";}}
 case "FILE_HASH" -> {boolean valid=target.matches("(?i)[0-9a-f]{64}");result=valid?"Valid SHA-256 indicator format. No malware database queried.":"Invalid SHA-256 hash (64 hexadecimal characters required)";if(!valid)status="FAILED";}
 default -> {String low=target.toLowerCase();int score=0;for(String token:new String[]{"failed","denied","unauthorized","bruteforce","malware","attack"})if(low.contains(token))score++;result="Offline log text keyword analysis: "+score+" suspicious keyword matches. This is heuristic triage, not verified threat detection.";}
 }
 int uid=(Integer)req.getSession(false).getAttribute("userId");try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement("INSERT INTO security_scans(user_id,scan_type,target,scan_status,scan_result,completed_at) VALUES(?,?,?,?,?,CURRENT_TIMESTAMP)")){p.setInt(1,uid);p.setString(2,type);p.setString(3,target);p.setString(4,status);p.setString(5,result);p.executeUpdate();new AuditDAO().log(uid,"SCAN","SECURITY_SCAN",null,type,req);}catch(SQLException e){throw new ServletException(e);}res.sendRedirect(req.getContextPath()+"/scans?requested=1");
 }
}
