package com.sentinelmind.web;

import jakarta.servlet.*;import jakarta.servlet.annotation.WebFilter;import jakarta.servlet.http.*;import java.io.IOException;import java.util.Set;
@WebFilter(urlPatterns={"/dashboard","/incidents","/incident-action","/threats","/threat-action","/scans","/assignments","/evidence", "/tasks", "/notifications", "/profile", "/reports", "/admin/users","/admin/*","/analyst/*","/user/*"})
public class AuthorizationFilter implements Filter {
 private static final Set<String> ROLES=Set.of("ADMIN","ANALYST","USER");
 @Override public void doFilter(ServletRequest request,ServletResponse response,FilterChain chain)throws IOException,ServletException{
  HttpServletRequest req=(HttpServletRequest)request;HttpServletResponse res=(HttpServletResponse)response;HttpSession s=req.getSession(false);
  if(s==null||s.getAttribute("userId")==null){res.sendRedirect(req.getContextPath()+"/login.jsp");return;}
  Object value=s.getAttribute("roleName");if(!(value instanceof String)){s.invalidate();res.sendRedirect(req.getContextPath()+"/login.jsp");return;}
  String role=((String)value).toUpperCase();if(!ROLES.contains(role)){res.sendError(403,"Unknown role");return;}
  String path=req.getServletPath();
  if(path.startsWith("/admin/")&&!role.equals("ADMIN")){res.sendError(403,"Administrator access required");return;}
  if(path.startsWith("/analyst/")&&!(role.equals("ADMIN")||role.equals("ANALYST"))){res.sendError(403,"Analyst access required");return;}
  if((path.equals("/threat-action")||path.equals("/threats"))&&"POST".equalsIgnoreCase(req.getMethod())&&!role.equals("ADMIN")){res.sendError(403,"Administrator access required to change threat records");return;}
  if(path.equals("/assignments")&&!(role.equals("ADMIN")||role.equals("ANALYST"))){res.sendError(403,"Analyst access required");return;}
  if(path.equals("/evidence")&&!(role.equals("ADMIN")||role.equals("ANALYST"))){res.sendError(403,"Analyst access required");return;}
  if(path.equals("/incident-action")&&"delete".equalsIgnoreCase(req.getParameter("action"))&&!role.equals("ADMIN")){res.sendError(403,"Administrator access required to delete incidents");return;}
  chain.doFilter(request,response);
 }
}
