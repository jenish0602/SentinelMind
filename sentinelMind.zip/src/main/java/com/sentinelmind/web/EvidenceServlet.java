
package com.sentinelmind.web;

import com.sentinelmind.config.DBConnection;
import com.sentinelmind.dao.AuditDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.*;
import java.util.*;

@WebServlet("/evidence")
public class EvidenceServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        List<Map<String, Object>> incidents = new ArrayList<>();
        List<Map<String, Object>> evidence = new ArrayList<>();

        try (Connection c = DBConnection.getConnection();
             PreparedStatement p = c.prepareStatement(
                     "SELECT incident_id, title FROM incidents ORDER BY created_at DESC");
             ResultSet r = p.executeQuery()) {

            while (r.next()) {
                Map<String, Object> m = new HashMap<>();
                m.put("id", r.getLong("incident_id"));
                m.put("title", r.getString("title"));
                incidents.add(m);
            }

        } catch (SQLException e) {
            throw new ServletException("Unable to load incidents.", e);
        }

        String sql = "SELECT e.evidence_id, e.incident_id, e.file_name, " +
                     "e.file_path, e.uploaded_at, i.title " +
                     "FROM incident_evidence e " +
                     "JOIN incidents i ON i.incident_id = e.incident_id " +
                     "ORDER BY e.uploaded_at DESC";

        try (Connection c = DBConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql);
             ResultSet r = p.executeQuery()) {

            while (r.next()) {
                Map<String, Object> m = new HashMap<>();
                m.put("id", r.getLong("evidence_id"));
                m.put("incidentId", r.getLong("incident_id"));
                m.put("fileName", r.getString("file_name"));
                m.put("path", r.getString("file_path"));
                m.put("at", r.getTimestamp("uploaded_at"));
                m.put("title", r.getString("title"));
                evidence.add(m);
            }

        } catch (SQLException e) {
            throw new ServletException("Unable to load evidence.", e);
        }

        req.setAttribute("incidents", incidents);
        req.setAttribute("evidence", evidence);

        req.getRequestDispatcher("/WEB-INF/views/evidence.jsp")
           .forward(req, res);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String file = req.getParameter("fileName");
        String path = req.getParameter("storagePath");

        HttpSession session = req.getSession(false);

        if (session == null || session.getAttribute("userId") == null) {
            res.sendError(HttpServletResponse.SC_UNAUTHORIZED);
            return;
        }

        try {
            long incidentId = Long.parseLong(req.getParameter("incidentId"));
            int userId = (Integer) session.getAttribute("userId");

            if (file == null || file.isBlank() || file.length() > 255
                    || path == null || path.isBlank() || path.length() > 500) {

                req.setAttribute("error",
                        "File name and storage reference are required.");
                doGet(req, res);
                return;
            }

            String sql = "INSERT INTO incident_evidence " +
                         "(incident_id, uploaded_by, file_name, file_path) " +
                         "VALUES (?, ?, ?, ?)";

            try (Connection c = DBConnection.getConnection();
                 PreparedStatement p = c.prepareStatement(sql)) {

                p.setLong(1, incidentId);
                p.setInt(2, userId);
                p.setString(3, file.trim());
                p.setString(4, path.trim());

                p.executeUpdate();
            }

            new AuditDAO().log(
                    userId,
                    "ADD_EVIDENCE",
                    "INCIDENT",
                    String.valueOf(incidentId),
                    file,
                    req
            );

            res.sendRedirect(req.getContextPath() + "/evidence?success=1");

        } catch (NumberFormatException e) {
            res.sendError(HttpServletResponse.SC_BAD_REQUEST,
                    "Invalid incident ID.");

        } catch (SQLException e) {
            throw new ServletException(
                    "Evidence metadata could not be saved.", e);
        }
    }
}
