package com.sentinelmind.web;

import com.sentinelmind.config.DBConnection;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.mindrot.jbcrypt.BCrypt;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HexFormat;

@WebServlet("/register")
public class RegistrationServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/register.jsp")
               .forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String fullName = request.getParameter("fullName");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirmPassword");
        String accessCode = request.getParameter("accessCode");

        if (fullName == null || email == null || password == null
                || confirmPassword == null || accessCode == null) {
            showError(request, response, "All fields are required.");
            return;
        }

        fullName = fullName.trim();
        email = email.trim().toLowerCase();
        accessCode = accessCode.trim();

        if (fullName.isEmpty() || email.isEmpty() || password.isEmpty()
                || confirmPassword.isEmpty() || accessCode.isEmpty()) {
            showError(request, response, "All fields are required.");
            return;
        }

        if (fullName.length() > 100 || email.length() > 150
                || accessCode.length() > 200) {
            showError(request, response, "One or more fields are too long.");
            return;
        }

        if (!email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")) {
            showError(request, response, "Enter a valid email address.");
            return;
        }

        if (password.length() < 12 || password.length() > 72) {
            showError(request, response,
                    "Password must contain 12 to 72 characters.");
            return;
        }

        if (!password.equals(confirmPassword)) {
            showError(request, response, "Passwords do not match.");
            return;
        }

        try (Connection con = DBConnection.getConnection()) {
            con.setAutoCommit(false);

            try {
                String codeSql =
                        "SELECT access_code_id, role_id " +
                        "FROM access_codes " +
                        "WHERE code_hash = ? " +
                        "AND is_active = TRUE " +
                        "AND used_count < max_uses " +
                        "AND (expires_at IS NULL OR expires_at > CURRENT_TIMESTAMP) " +
                        "FOR UPDATE";

                int accessCodeId;
                int roleId;

                try (PreparedStatement ps = con.prepareStatement(codeSql)) {
                    ps.setString(1, hashAccessCode(accessCode));

                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) {
                            con.rollback();
                            showError(request, response,
                                    "Invalid, expired, or exhausted registration code.");
                            return;
                        }

                        accessCodeId = rs.getInt("access_code_id");
                        roleId = rs.getInt("role_id");
                    }
                }

                try (PreparedStatement ps = con.prepareStatement(
                        "SELECT user_id FROM users WHERE email = ?")) {

                    ps.setString(1, email);

                    try (ResultSet rs = ps.executeQuery()) {
                        if (rs.next()) {
                            con.rollback();
                            showError(request, response,
                                    "An account with this email already exists.");
                            return;
                        }
                    }
                }

                String passwordHash =
                        BCrypt.hashpw(password, BCrypt.gensalt(12));

                String insertSql =
                        "INSERT INTO users " +
                        "(role_id, full_name, email, password_hash, status, " +
                        "failed_login_attempts, created_at, updated_at) " +
                        "VALUES (?, ?, ?, ?, 'ACTIVE', 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)";

                try (PreparedStatement ps = con.prepareStatement(insertSql)) {
                    ps.setInt(1, roleId);
                    ps.setString(2, fullName);
                    ps.setString(3, email);
                    ps.setString(4, passwordHash);
                    ps.executeUpdate();
                }

                try (PreparedStatement ps = con.prepareStatement(
                        "UPDATE access_codes " +
                        "SET used_count = used_count + 1 " +
                        "WHERE access_code_id = ? AND used_count < max_uses")) {

                    ps.setInt(1, accessCodeId);

                    if (ps.executeUpdate() != 1) {
                        throw new SQLException(
                                "Registration code usage could not be updated.");
                    }
                }

                con.commit();

                response.sendRedirect(
                        request.getContextPath() + "/login.jsp?registered=1");

            } catch (SQLException | ServletException | IOException
                     | RuntimeException ex) {
                try {
                    con.rollback();
                } catch (SQLException rollbackError) {
                    ex.addSuppressed(rollbackError);
                }
                throw ex;
            } finally {
                try {
                    con.setAutoCommit(true);
                } catch (SQLException ignored) {
                    // The connection is closed after this request.
                }
            }

        } catch (SQLException e) {
            throw new ServletException(
                    "Registration failed. Check the database schema and connection.", e);
        } catch (NoSuchAlgorithmException e) {
            throw new ServletException(
                    "Unable to process the registration code.", e);
        }
    }

    private String hashAccessCode(String code)
            throws NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(code.getBytes(StandardCharsets.UTF_8));
        return HexFormat.of().formatHex(hash);
    }

    private void showError(HttpServletRequest request,
                           HttpServletResponse response,
                           String message)
            throws ServletException, IOException {
        request.setAttribute("error", message);
        request.getRequestDispatcher("/register.jsp")
               .forward(request, response);
    }
}