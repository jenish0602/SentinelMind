package com.sentinelmind.web;

import com.sentinelmind.dao.MonitoringDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/admin/monitoring")
public class AdminMonitoringServlet extends HttpServlet {
    private final MonitoringDAO dao = new MonitoringDAO();
    @Override protected void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException {
        if(req.getSession(false)==null || !"ADMIN".equals(req.getSession(false).getAttribute("roleName"))){res.sendError(403);return;}
        try {
            req.setAttribute("summary",dao.summary());
            req.setAttribute("presence",dao.presence());
            req.setAttribute("activity",dao.recentActivity());
            req.getRequestDispatcher("/WEB-INF/views/admin-monitoring.jsp").forward(req,res);
        } catch(Exception e){throw new ServletException("Unable to load monitoring dashboard. Run the XAMPP monitoring migration first.",e);}
    }
}
