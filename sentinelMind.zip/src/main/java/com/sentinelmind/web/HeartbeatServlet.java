package com.sentinelmind.web;
import com.sentinelmind.dao.MonitoringDAO;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import jakarta.servlet.*;
import java.io.IOException;

@WebServlet("/heartbeat")
public class HeartbeatServlet extends HttpServlet {
    private final MonitoringDAO dao=new MonitoringDAO();
    @Override protected void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{
        HttpSession s=req.getSession(false);
        if(s==null || !(s.getAttribute("userId") instanceof Integer) || !(s.getAttribute("monitorSessionId") instanceof Long)){res.sendError(401);return;}
        try{dao.touchSession((Long)s.getAttribute("monitorSessionId"),(Integer)s.getAttribute("userId"));res.setStatus(204);}
        catch(Exception e){throw new ServletException("Heartbeat update failed.",e);}
    }
}
