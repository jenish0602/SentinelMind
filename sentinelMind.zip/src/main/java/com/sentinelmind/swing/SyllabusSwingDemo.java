package com.sentinelmind.swing;

import com.sentinelmind.config.DBConnection;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

/** Standalone Swing/JDBC syllabus client for viewing and managing incident records. */
public class SyllabusSwingDemo {
    private final JFrame frame = new JFrame("SentinelMind | Swing Incident Console");
    private final JTextField title = new JTextField();
    private final JTextField reporterId = new JTextField("1");
    private final JTextArea description = new JTextArea(3, 24);
    private final JComboBox<String> severity = new JComboBox<>(new String[]{"LOW", "MEDIUM", "HIGH", "CRITICAL"});
    private final JComboBox<String> status = new JComboBox<>(new String[]{"OPEN", "IN_PROGRESS", "RESOLVED", "CLOSED"});
    private final DefaultTableModel model = new DefaultTableModel(new String[]{"ID", "Title", "Severity", "Status", "Reporter", "Created"}, 0) {
        @Override public boolean isCellEditable(int row, int column) { return false; }
    };
    private final JTable table = new JTable(model);

    public static void main(String[] args) { SwingUtilities.invokeLater(() -> new SyllabusSwingDemo().show()); }

    private void show() {
        frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        frame.setMinimumSize(new Dimension(900, 620));
        frame.setLayout(new BorderLayout(12, 12));
        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createTitledBorder("Create incident (JDBC + PreparedStatement)"));
        GridBagConstraints g = new GridBagConstraints(); g.insets = new Insets(5, 7, 5, 7); g.fill = GridBagConstraints.HORIZONTAL;
        addField(form, g, 0, "Title", title); addField(form, g, 1, "Reporter user ID", reporterId); addField(form, g, 2, "Severity", severity);
        g.gridx=0;g.gridy=3;g.gridwidth=1;form.add(new JLabel("Description"),g);g.gridx=1;g.gridwidth=2;form.add(new JScrollPane(description),g);
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT)); JButton add=new JButton("Add Incident"), refresh=new JButton("Refresh"), update=new JButton("Update Selected Status"), delete=new JButton("Delete Selected");
        buttons.add(add);buttons.add(refresh);buttons.add(new JLabel("New status:"));buttons.add(status);buttons.add(update);buttons.add(delete);
        JPanel top = new JPanel(new BorderLayout());top.add(form,BorderLayout.CENTER);top.add(buttons,BorderLayout.SOUTH);frame.add(top,BorderLayout.NORTH);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);table.setAutoCreateRowSorter(true);frame.add(new JScrollPane(table),BorderLayout.CENTER);
        add.addActionListener(e -> addIncident());refresh.addActionListener(e -> loadIncidents());update.addActionListener(e -> updateStatus());delete.addActionListener(e -> deleteIncident());
        frame.add(new JLabel("Educational local desktop client. Requires MySQL and the project database."),BorderLayout.SOUTH);
        loadIncidents();frame.pack();frame.setLocationRelativeTo(null);frame.setVisible(true);
    }
    private void addField(JPanel panel, GridBagConstraints g, int row, String label, Component component) { g.gridy=row;g.gridx=0;g.gridwidth=1;panel.add(new JLabel(label),g);g.gridx=1;g.gridwidth=2;panel.add(component,g); }
    private void addIncident() {
        String t=title.getText().trim(),d=description.getText().trim();
        if(t.isEmpty()||t.length()>180||d.isEmpty()){showError("Title (max 180 characters) and description are required.");return;}
        try {int uid=Integer.parseInt(reporterId.getText().trim());try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement("INSERT INTO incidents(title,description,severity,reported_by) VALUES(?,?,?,?)")){p.setString(1,t);p.setString(2,d);p.setString(3,(String)severity.getSelectedItem());p.setInt(4,uid);p.executeUpdate();}title.setText("");description.setText("");loadIncidents();JOptionPane.showMessageDialog(frame,"Incident created.");}
        catch(NumberFormatException e){showError("Reporter user ID must be numeric.");}catch(SQLException e){showError("Could not create incident. Check reporter ID and database connection.\n"+e.getMessage());}
    }
    private void loadIncidents() {
        model.setRowCount(0);String sql="SELECT incident_id,title,severity,status,reported_by,created_at FROM incidents ORDER BY created_at DESC";
        try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement(sql);ResultSet r=p.executeQuery()){while(r.next())model.addRow(new Object[]{r.getLong(1),r.getString(2),r.getString(3),r.getString(4),r.getInt(5),r.getTimestamp(6)});}
        catch(SQLException e){showError("Could not load incidents. Ensure MySQL is running and import sentinelmind_db.sql.\n"+e.getMessage());}
    }
    private Long selectedId(){int row=table.getSelectedRow();if(row<0){showError("Select an incident row first.");return null;}return ((Number)model.getValueAt(table.convertRowIndexToModel(row),0)).longValue();}
    private void updateStatus(){Long id=selectedId();if(id==null)return;try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement("UPDATE incidents SET status=? WHERE incident_id=?")){p.setString(1,(String)status.getSelectedItem());p.setLong(2,id);if(p.executeUpdate()==0)showError("Incident not found.");loadIncidents();}catch(SQLException e){showError("Status update failed.\n"+e.getMessage());}}
    private void deleteIncident(){Long id=selectedId();if(id==null)return;if(JOptionPane.showConfirmDialog(frame,"Delete incident #"+id+" and its linked evidence/assignments?","Confirm delete",JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION)return;try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement("DELETE FROM incidents WHERE incident_id=?")){p.setLong(1,id);p.executeUpdate();loadIncidents();}catch(SQLException e){showError("Delete failed. Check database constraints.\n"+e.getMessage());}}
    private void showError(String message){JOptionPane.showMessageDialog(frame,message,"SentinelMind",JOptionPane.ERROR_MESSAGE);}
}
