package com.sentinelmind.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/** JDBC connection helper. Override settings with SM_DB_URL, SM_DB_USER and SM_DB_PASSWORD. */
public final class DBConnection {
    private static final String URL =
    "jdbc:mysql://localhost:3306/sentinelmind_db";
        private static final String USER = "root";
        private static final String PASSWORD = "";
    private DBConnection() { }
    private static String setting(String key, String fallback) {
        String value = System.getenv(key);
        return value == null || value.isBlank() ? fallback : value;
    }
    public static Connection getConnection() throws SQLException {
        try { Class.forName("com.mysql.cj.jdbc.Driver"); }
        catch (ClassNotFoundException e) { throw new SQLException("MySQL JDBC Driver not found. Check Maven dependency.", e); }
        return DriverManager.getConnection(setting("SM_DB_URL", URL), setting("SM_DB_USER", USER), setting("SM_DB_PASSWORD", PASSWORD));
    }
}
