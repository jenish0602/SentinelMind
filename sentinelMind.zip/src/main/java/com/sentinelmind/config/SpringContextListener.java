package com.sentinelmind.config;
import jakarta.servlet.ServletContextEvent;import jakarta.servlet.ServletContextListener;import jakarta.servlet.annotation.WebListener;import org.springframework.context.annotation.AnnotationConfigApplicationContext;
@WebListener public class SpringContextListener implements ServletContextListener {
 public static final String CONTEXT_KEY="sentinelSpringContext";
 @Override public void contextInitialized(ServletContextEvent event){AnnotationConfigApplicationContext ctx=new AnnotationConfigApplicationContext(SpringConfig.class);event.getServletContext().setAttribute(CONTEXT_KEY,ctx);}
 @Override public void contextDestroyed(ServletContextEvent event){Object o=event.getServletContext().getAttribute(CONTEXT_KEY);if(o instanceof AnnotationConfigApplicationContext c)c.close();try{HibernateUtil.shutdown();}catch(Exception ignored){}}
}
