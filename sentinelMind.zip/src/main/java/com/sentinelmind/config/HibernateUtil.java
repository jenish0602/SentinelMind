package com.sentinelmind.config;
import com.sentinelmind.entity.Threat;import org.hibernate.SessionFactory;import org.hibernate.cfg.Configuration;import java.util.Properties;
public final class HibernateUtil {
 private static volatile SessionFactory factory;private HibernateUtil(){}
 private static SessionFactory build(){Properties p=new Properties();p.put("hibernate.connection.driver_class","com.mysql.cj.jdbc.Driver");p.put("hibernate.connection.url",env("SM_DB_URL","jdbc:mysql://localhost:3306/sentinelmind_db?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true"));p.put("hibernate.connection.username",env("SM_DB_USER","root"));p.put("hibernate.connection.password",env("SM_DB_PASSWORD",""));p.put("hibernate.dialect","org.hibernate.dialect.MySQLDialect");p.put("hibernate.hbm2ddl.auto","none");p.put("hibernate.show_sql","false");return new Configuration().setProperties(p).addAnnotatedClass(Threat.class).buildSessionFactory();}
 private static String env(String k,String d){String v=System.getenv(k);return v==null||v.isBlank()?d:v;}
 public static SessionFactory getSessionFactory(){if(factory==null){synchronized(HibernateUtil.class){if(factory==null)factory=build();}}return factory;}
 public static void shutdown(){SessionFactory f=factory;if(f!=null&&!f.isClosed())f.close();}
}