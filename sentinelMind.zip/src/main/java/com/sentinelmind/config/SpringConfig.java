package com.sentinelmind.config;
import com.sentinelmind.dao.IncidentDAO;import com.sentinelmind.dao.ThreatDAO;import com.sentinelmind.service.IncidentService;import com.sentinelmind.service.ThreatService;import org.springframework.context.annotation.Bean;import org.springframework.context.annotation.ComponentScan;import org.springframework.context.annotation.Configuration;
@Configuration @ComponentScan(basePackages="com.sentinelmind")
public class SpringConfig {
 @Bean public IncidentDAO incidentDAO(){return new IncidentDAO();}
 @Bean public IncidentService incidentService(IncidentDAO dao){return new IncidentService(dao);}
 @Bean public ThreatDAO threatDAO(){return new ThreatDAO();}
 @Bean public ThreatService threatService(ThreatDAO dao){return new ThreatService(dao);}
}
