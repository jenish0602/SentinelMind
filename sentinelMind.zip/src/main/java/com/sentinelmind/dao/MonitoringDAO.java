
package com.sentinelmind.dao;

import com.sentinelmind.config.DBConnection;
import java.sql.*;
import java.util.*;

public class MonitoringDAO {

    // Start a new user session
    public long startSession(int userId, String tokenHash,
                             String ip, String agent) throws SQLException {

        String sql = "INSERT INTO user_sessions " +
                     "(session_token, user_id, ip_address, user_agent, session_status) " +
                     "VALUES (?, ?, ?, ?, 'ONLINE')";

        try (Connection c = DBConnection.getConnection();
             PreparedStatement p = c.prepareStatement(
                     sql, Statement.RETURN_GENERATED_KEYS)) {

            p.setString(1, tokenHash);
            p.setInt(2, userId);
            p.setString(3, ip);
            p.setString(4, agent);

            p.executeUpdate();

            try (ResultSet r = p.getGeneratedKeys()) {
                if (r.next()) {
                    return r.getLong(1);
                }
            }
        }

        throw new SQLException("Could not create monitoring session.");
    }

    // Update session activity and save heartbeat
    public void touchSession(long sessionId, int userId)
            throws SQLException {

        String updateSql =
                "UPDATE user_sessions SET last_activity = NOW() " +
                "WHERE session_id = ? AND user_id = ? " +
                "AND session_status = 'ONLINE'";

        try (Connection c = DBConnection.getConnection();
             PreparedStatement p = c.prepareStatement(updateSql)) {

            p.setLong(1, sessionId);
            p.setInt(2, userId);
            p.executeUpdate();
        }

        String heartbeatSql =
                "INSERT INTO heartbeats (user_id, session_id, heartbeat_time) " +
                "VALUES (?, ?, NOW())";

        try (Connection c = DBConnection.getConnection();
             PreparedStatement p = c.prepareStatement(heartbeatSql)) {

            p.setInt(1, userId);
            p.setLong(2, sessionId);
            p.executeUpdate();
        }
    }

    // Close user session
    public void closeSession(long sessionId) throws SQLException {

        String sql =
                "UPDATE user_sessions SET " +
                "session_status = 'OFFLINE', " +
                "logout_at = NOW(), " +
                "last_activity = NOW() " +
                "WHERE session_id = ? AND session_status = 'ONLINE'";

        try (Connection c = DBConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql)) {

            p.setLong(1, sessionId);
            p.executeUpdate();
        }
    }

    // Record page visit
    public void logPage(int userId, Long sessionId,
                        String path, String ip) throws SQLException {

        String sql =
                "INSERT INTO activity_logs " +
                "(user_id, session_id, activity_type, page_url, ip_address) " +
                "VALUES (?, ?, 'PAGE_VIEW', ?, ?)";

        try (Connection c = DBConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql)) {

            p.setInt(1, userId);

            if (sessionId == null) {
                p.setNull(2, Types.BIGINT);
            } else {
                p.setLong(2, sessionId);
            }

            p.setString(3, path);
            p.setString(4, ip);

            p.executeUpdate();
        }
    }

    // Dashboard summary
    public Map<String, Object> summary() throws SQLException {

        Map<String, Object> data = new LinkedHashMap<>();

        String totalSql = "SELECT COUNT(*) FROM users";

        String presenceSql =
                "SELECT " +
                "SUM(session_status = 'ONLINE' AND " +
                "last_activity >= NOW() - INTERVAL 5 MINUTE) AS online, " +
                "SUM(session_status = 'ONLINE' AND " +
                "last_activity < NOW() - INTERVAL 5 MINUTE) AS stale " +
                "FROM v_user_presence";

        String loginSql =
                "SELECT COUNT(*) FROM user_sessions " +
                "WHERE DATE(login_at) = CURDATE()";

        String activitySql =
                "SELECT COUNT(*) FROM activity_logs " +
                "WHERE DATE(created_at) = CURDATE()";

        try (Connection c = DBConnection.getConnection();
             Statement s = c.createStatement()) {

            try (ResultSet r = s.executeQuery(totalSql)) {
                if (r.next()) {
                    data.put("totalUsers", r.getInt(1));
                }
            }

            try (ResultSet r = s.executeQuery(presenceSql)) {
                if (r.next()) {
                    data.put("onlineUsers", r.getInt("online"));
                    data.put("staleUsers", r.getInt("stale"));
                }
            }

            try (ResultSet r = s.executeQuery(loginSql)) {
                if (r.next()) {
                    data.put("loginsToday", r.getInt(1));
                }
            }

            try (ResultSet r = s.executeQuery(activitySql)) {
                if (r.next()) {
                    data.put("pageViewsToday", r.getInt(1));
                }
            }
        }

        return data;
    }

    // Get user presence information
    public List<Map<String, Object>> presence() throws SQLException {

        List<Map<String, Object>> rows = new ArrayList<>();

        String sql =
                "SELECT user_id, full_name, email, role_name, " +
                "session_id, login_at, last_activity, session_status, ip_address " +
                "FROM v_user_presence " +
                "ORDER BY FIELD(session_status, 'ONLINE', 'OFFLINE'), full_name";

        try (Connection c = DBConnection.getConnection();
             Statement s = c.createStatement();
             ResultSet r = s.executeQuery(sql)) {

            while (r.next()) {

                Map<String, Object> item = new LinkedHashMap<>();

                Timestamp lastActivity = r.getTimestamp("last_activity");
                String sessionStatus = r.getString("session_status");

                String displayStatus;

                if ("ONLINE".equalsIgnoreCase(sessionStatus)) {
                    if (lastActivity != null &&
                        lastActivity.getTime() >= System.currentTimeMillis() - 300000) {
                        displayStatus = "ONLINE";
                    } else {
                        displayStatus = "IDLE_OR_STALE";
                    }
                } else {
                    displayStatus = "OFFLINE";
                }

                item.put("userId", r.getInt("user_id"));
                item.put("name", r.getString("full_name"));
                item.put("email", r.getString("email"));
                item.put("role", r.getString("role_name"));
                item.put("sessionId", r.getObject("session_id"));
                item.put("loginAt", r.getTimestamp("login_at"));
                item.put("lastSeen", lastActivity);
                item.put("status", displayStatus);
                item.put("ip", r.getString("ip_address"));

                rows.add(item);
            }
        }

        return rows;
    }

    // Get latest user activity
    public List<Map<String, Object>> recentActivity() throws SQLException {

        List<Map<String, Object>> rows = new ArrayList<>();

        String sql =
                "SELECT a.created_at, u.full_name, a.page_url, " +
                "a.activity_type, a.ip_address " +
                "FROM activity_logs a " +
                "JOIN users u ON u.user_id = a.user_id " +
                "ORDER BY a.created_at DESC LIMIT 100";

        try (Connection c = DBConnection.getConnection();
             Statement s = c.createStatement();
             ResultSet r = s.executeQuery(sql)) {

            while (r.next()) {

                Map<String, Object> item = new LinkedHashMap<>();

                item.put("createdAt", r.getTimestamp("created_at"));
                item.put("name", r.getString("full_name"));
                item.put("page", r.getString("page_url"));
                item.put("action", r.getString("activity_type"));
                item.put("ip", r.getString("ip_address"));

                rows.add(item);
            }
        }

        return rows;
    }
}
