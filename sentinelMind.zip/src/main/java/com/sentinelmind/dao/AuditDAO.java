package com.sentinelmind.dao;
import com.sentinelmind.config.DBConnection;import jakarta.servlet.http.HttpServletRequest;import java.sql.*;
public class AuditDAO {
 public void log(Integer userId,String action,String entityType,String entityId,String details,HttpServletRequest request){
  String sql="INSERT INTO audit_logs(user_id,action,entity_type,entity_id,details,ip_address) VALUES(?,?,?,?,?,?)";
  try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement(sql)){if(userId==null)p.setNull(1,Types.INTEGER);else p.setInt(1,userId);p.setString(2,action);p.setString(3,entityType);p.setString(4,entityId);p.setString(5,details);p.setString(6,request==null?null:request.getRemoteAddr());p.executeUpdate();}catch(SQLException ignored){/* Audit failure must not hide the primary operation; monitor DB logs in production. */}
 }
}
