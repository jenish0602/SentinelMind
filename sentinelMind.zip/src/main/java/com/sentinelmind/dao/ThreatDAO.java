package com.sentinelmind.dao;
import com.sentinelmind.config.HibernateUtil;import com.sentinelmind.entity.Threat;import org.hibernate.Session;import org.hibernate.Transaction;import java.util.List;
/** Hibernate ORM repository demonstrating entity persistence and transaction handling. */
public class ThreatDAO {
 public List<Threat> findAll(){try(Session s=HibernateUtil.getSessionFactory().openSession()){return s.createQuery("from Threat t order by t.threatId desc",Threat.class).getResultList();}}
 public Threat findById(long id){try(Session s=HibernateUtil.getSessionFactory().openSession()){return s.get(Threat.class,id);}}
 public void save(Threat t){Transaction tx=null;try(Session s=HibernateUtil.getSessionFactory().openSession()){tx=s.beginTransaction();s.persist(t);tx.commit();}catch(RuntimeException e){if(tx!=null&&tx.isActive())tx.rollback();throw e;}}
 public boolean update(Threat t){Transaction tx=null;try(Session s=HibernateUtil.getSessionFactory().openSession()){tx=s.beginTransaction();Threat existing=s.get(Threat.class,t.getThreatId());if(existing==null){tx.rollback();return false;}existing.setThreatName(t.getThreatName());existing.setCategory(t.getCategory());existing.setRiskLevel(t.getRiskLevel());existing.setMitigation(t.getMitigation());tx.commit();return true;}catch(RuntimeException e){if(tx!=null&&tx.isActive())tx.rollback();throw e;}}
 public boolean delete(long id){Transaction tx=null;try(Session s=HibernateUtil.getSessionFactory().openSession()){tx=s.beginTransaction();Threat t=s.get(Threat.class,id);if(t==null){tx.rollback();return false;}s.remove(t);tx.commit();return true;}catch(RuntimeException e){if(tx!=null&&tx.isActive())tx.rollback();throw e;}}
}
