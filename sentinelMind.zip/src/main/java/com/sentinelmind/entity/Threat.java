package com.sentinelmind.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "threats")
public class Threat {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "threat_id")
    private Long threatId;
    @Column(name = "threat_name", nullable = false, length = 160)
    private String threatName;
    @Column(name = "threat_type", length = 100)
    private String category;
    @Column(name = "risk_level", nullable = false, length = 20)
    private String riskLevel;
    @Column(name = "description", columnDefinition = "TEXT")
    private String mitigation;

    public Long getThreatId() { return threatId; }
    public void setThreatId(Long threatId) { this.threatId = threatId; }
    public String getThreatName() { return threatName; }
    public void setThreatName(String threatName) { this.threatName = threatName; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public String getRiskLevel() { return riskLevel; }
    public void setRiskLevel(String riskLevel) { this.riskLevel = riskLevel; }
    public String getMitigation() { return mitigation; }
    public void setMitigation(String mitigation) { this.mitigation = mitigation; }
}
