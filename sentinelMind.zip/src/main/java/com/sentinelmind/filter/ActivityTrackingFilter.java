package com.sentinelmind.filter;

import com.sentinelmind.dao.MonitoringDAO;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebFilter("/*")
public class ActivityTrackingFilter implements Filter {

    private final MonitoringDAO dao = new MonitoringDAO();
    private ServletContext servletContext;

    @Override
    public void init(FilterConfig filterConfig) {
        this.servletContext = filterConfig.getServletContext();
    }

    @Override
    public void doFilter(
            ServletRequest request,
            ServletResponse response,
            FilterChain chain
    ) throws IOException, ServletException {

        HttpServletRequest req = (HttpServletRequest) request;
        HttpSession session = req.getSession(false);

        Object uid = session == null
                ? null
                : session.getAttribute("userId");

        if (uid instanceof Integer && !isStatic(req.getRequestURI())) {

            try {
                Object sid = session.getAttribute("monitorSessionId");

                if (sid instanceof Long) {

                    long sessionId = (Long) sid;
                    int userId = (Integer) uid;

                    dao.touchSession(sessionId, userId);

                    String path = req.getServletPath();

                    if (path != null && !path.equals("/heartbeat")) {
                        dao.logPage(userId, sessionId, path, clientIp(req));
                    }
                }

            } catch (Exception ex) {

                if (servletContext != null) {
                    servletContext.log("Activity tracking failed", ex);
                }
            }
        }

        chain.doFilter(request, response);
    }

    private boolean isStatic(String uri) {

        if (uri == null) {
            return false;
        }

        String p = uri.toLowerCase();

        return p.contains("/assets/")
                || p.endsWith(".css")
                || p.endsWith(".js")
                || p.endsWith(".png")
                || p.endsWith(".jpg")
                || p.endsWith(".jpeg")
                || p.endsWith(".ico")
                || p.endsWith(".woff")
                || p.endsWith(".woff2")
                || p.endsWith(".svg");
    }

    private String clientIp(HttpServletRequest req) {
        return req.getRemoteAddr();
    }

    @Override
    public void destroy() {
        // No resources to release.
    }
}
