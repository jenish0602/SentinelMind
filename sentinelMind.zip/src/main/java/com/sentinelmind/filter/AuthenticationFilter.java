package com.sentinelmind.filter;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebFilter(urlPatterns = {"/dashboard", "/incidents", "/incident-action", "/threats", "/threat-action", "/scan-request", "/scans", "/assignments", "/evidence", "/tasks", "/notifications", "/profile", "/reports", "/admin/users", "/admin/*", "/analyst/*", "/user/*"})
public class AuthenticationFilter implements Filter {
    @Override public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest req=(HttpServletRequest)request; HttpServletResponse res=(HttpServletResponse)response;
        res.setHeader("Cache-Control","no-store, no-cache, must-revalidate"); res.setHeader("Pragma","no-cache"); res.setHeader("X-Content-Type-Options","nosniff"); res.setHeader("X-Frame-Options","DENY");
        HttpSession session=req.getSession(false);
        if(session==null || session.getAttribute("userId")==null){res.sendRedirect(req.getContextPath()+"/login.jsp");return;}
        chain.doFilter(request,response);
    }
}
