<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%!
    private String escapeHtml(String value) {
        if (value == null) return "";
        return value.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;")
                    .replace("'", "&#39;");
    }
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Account | SentinelMind</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 30px 16px;
            font-family: "Segoe UI", Arial, sans-serif;
            color: #eaf0ff;
            background:
                radial-gradient(circle at top left, #15345a 0, transparent 40%),
                linear-gradient(135deg, #070b16, #101a2d);
        }

        .container {
            width: 100%;
            max-width: 1050px;
            min-height: 650px;
            display: grid;
            grid-template-columns: 0.9fr 1.1fr;
            overflow: hidden;
            border: 1px solid #293956;
            border-radius: 22px;
            background: #0d1525;
            box-shadow: 0 25px 70px rgba(0, 0, 0, 0.45);
        }

        .left-panel {
            display: flex;
            flex-direction: column;
            justify-content: center;
            padding: 48px;
            background: linear-gradient(155deg, #102b4b, #101729 75%);
        }

        .brand {
            color: #65d7ff;
            font-size: 15px;
            font-weight: 800;
            letter-spacing: 3px;
            text-transform: uppercase;
        }

        .left-panel h1 {
            margin: 25px 0 18px;
            font-size: 39px;
            line-height: 1.2;
        }

        .left-panel p {
            color: #aebbd2;
            line-height: 1.8;
            font-size: 15px;
        }

        .features {
            margin-top: 35px;
            list-style: none;
        }

        .features li {
            margin: 15px 0;
            color: #d8e4f7;
            font-size: 14px;
        }

        .features li::before {
            content: "✓";
            color: #5be0bd;
            font-weight: bold;
            margin-right: 12px;
        }

        .right-panel {
            padding: 42px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .right-panel h2 {
            font-size: 29px;
            margin-bottom: 10px;
        }

        .subtitle {
            color: #9eacc5;
            font-size: 14px;
            margin-bottom: 25px;
            line-height: 1.6;
        }

        .error {
            background: rgba(255, 75, 100, 0.12);
            color: #ff9eaa;
            border: 1px solid rgba(255, 75, 100, 0.35);
            border-radius: 9px;
            padding: 12px;
            margin-bottom: 18px;
            font-size: 13px;
            overflow-wrap: anywhere;
        }

        .form-group {
            margin-bottom: 17px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #dce6f7;
            font-size: 13px;
            font-weight: 600;
        }

        input {
            width: 100%;
            padding: 13px 14px;
            color: #f2f6ff;
            background: #101d31;
            border: 1px solid #31425e;
            border-radius: 9px;
            outline: none;
            font-size: 14px;
            transition: border-color 0.2s, box-shadow 0.2s;
        }

        input:focus {
            border-color: #48c9f5;
            box-shadow: 0 0 0 3px rgba(72, 201, 245, 0.12);
        }

        input::placeholder {
            color: #71819d;
        }

        small {
            display: block;
            margin-top: 7px;
            color: #93a5c1;
            font-size: 12px;
            line-height: 1.5;
        }

        .security-note {
            padding: 12px;
            margin: 3px 0 18px;
            border-radius: 8px;
            background: rgba(65, 198, 244, 0.07);
            border: 1px solid rgba(65, 198, 244, 0.18);
            color: #a9cde3;
            font-size: 12px;
            line-height: 1.6;
        }

        button {
            width: 100%;
            padding: 14px;
            border: none;
            border-radius: 9px;
            color: #07111f;
            background: linear-gradient(90deg, #55d4f5, #70e5c4);
            font-size: 15px;
            font-weight: 800;
            cursor: pointer;
            transition: transform 0.2s, filter 0.2s;
        }

        button:hover {
            transform: translateY(-2px);
            filter: brightness(1.07);
        }

        .login-link {
            text-align: center;
            margin-top: 22px;
            color: #aab7cc;
            font-size: 13px;
        }

        a {
            color: #65d7ff;
            font-weight: 700;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        .footer {
            margin-top: 25px;
            text-align: center;
            color: #71819b;
            font-size: 11px;
            line-height: 1.7;
        }

        @media (max-width: 760px) {
            .container {
                max-width: 520px;
                grid-template-columns: 1fr;
            }

            .left-panel {
                padding: 30px;
            }

            .left-panel h1 {
                font-size: 30px;
                margin: 15px 0;
            }

            .features {
                margin-top: 18px;
            }

            .features li {
                margin: 10px 0;
            }

            .right-panel {
                padding: 30px 24px;
            }
        }
    </style>
</head>

<body>
<div class="container">

    <section class="left-panel">
        <div class="brand">SentinelMind</div>

        <h1>Secure Your<br>Digital World.</h1>

        <p>
            Create your account to access the SentinelMind cyber security
            platform. Your registration code determines your assigned role
            and access permissions.
        </p>

        <ul class="features">
            <li>Role-based access control</li>
            <li>Secure password hashing</li>
            <li>Incident and threat management</li>
            <li>Controlled account registration</li>
        </ul>
    </section>

    <section class="right-panel">
        <h2>Create Account</h2>

        <p class="subtitle">
            Enter your details and the authorized registration code provided to you.
        </p>

        <% if (request.getAttribute("error") != null) { %>
            <div class="error" role="alert">
                <%= escapeHtml(String.valueOf(request.getAttribute("error"))) %>
            </div>
        <% } %>

        <form action="${pageContext.request.contextPath}/register"
              method="post"
              accept-charset="UTF-8">

            <div class="form-group">
                <label for="fullName">Full Name</label>
                <input
                    type="text"
                    id="fullName"
                    name="fullName"
                    placeholder="Enter your full name"
                    maxlength="100"
                    autocomplete="name"
                    required>
            </div>

            <div class="form-group">
                <label for="email">Email Address</label>
                <input
                    type="email"
                    id="email"
                    name="email"
                    placeholder="you@example.com"
                    maxlength="150"
                    autocomplete="email"
                    required>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input
                    type="password"
                    id="password"
                    name="password"
                    placeholder="Create a strong password"
                    minlength="12"
                    maxlength="72"
                    autocomplete="new-password"
                    required>
                <small>Use 12 to 72 characters.</small>
            </div>

            <div class="form-group">
                <label for="confirmPassword">Confirm Password</label>
                <input
                    type="password"
                    id="confirmPassword"
                    name="confirmPassword"
                    placeholder="Re-enter your password"
                    minlength="12"
                    maxlength="72"
                    autocomplete="new-password"
                    required>
            </div>

            <div class="form-group">
                <label for="accessCode">Registration Access Code</label>
                <input
                    type="password"
                    id="accessCode"
                    name="accessCode"
                    placeholder="Enter your authorized access code"
                    maxlength="200"
                    autocomplete="off"
                    required>
                <small>
                    Your assigned role is determined by the verified code.
                    Do not share administrator codes.
                </small>
            </div>

            <div class="security-note">
                Registration codes have role-specific permissions and usage
                limits. Never enter a code that was not issued to you.
            </div>

            <button type="submit">Create Secure Account</button>
        </form>

        <div class="login-link">
            Already have an account?
            <a href="${pageContext.request.contextPath}/login.jsp">Sign in</a>
        </div>

        <div class="footer">
            SentinelMind Cyber Security Platform<br>
            Authorized access only.
        </div>
    </section>

</div>
</body>
</html>