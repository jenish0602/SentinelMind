<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Login | SentinelMind</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 25px;
            font-family: Arial, Helvetica, sans-serif;
            background:
                radial-gradient(circle at top left, #12365b, transparent 40%),
                radial-gradient(circle at bottom right, #102b43, transparent 40%),
                #080f1d;
            color: #e5edf8;
        }

        .container {
            width: 100%;
            max-width: 1050px;
            min-height: 600px;
            display: grid;
            grid-template-columns: 1fr 1fr;
            overflow: hidden;
            border: 1px solid #263b55;
            border-radius: 20px;
            background: #101b2d;
            box-shadow: 0 25px 70px rgba(0, 0, 0, 0.45);
        }

        .left-panel {
            padding: 55px 45px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            background: linear-gradient(145deg, #102d4b, #0b1728);
        }

        .brand {
            color: #38bdf8;
            font-size: 29px;
            font-weight: 800;
            letter-spacing: 0.5px;
            margin-bottom: 18px;
        }

        .brand span {
            color: #f1f5f9;
        }

        .left-panel h1 {
            font-size: 38px;
            line-height: 1.2;
            margin-bottom: 20px;
        }

        .left-panel h1 span {
            color: #38bdf8;
        }

        .description {
            color: #a6b7cd;
            line-height: 1.8;
            font-size: 15px;
            margin-bottom: 32px;
        }

        .feature {
            display: flex;
            align-items: center;
            gap: 13px;
            margin: 13px 0;
            color: #d4e3f5;
            font-size: 14px;
        }

        .feature-icon {
            width: 35px;
            height: 35px;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 1px solid #28577c;
            border-radius: 9px;
            background: #122f4c;
            color: #38bdf8;
            font-size: 17px;
        }

        .right-panel {
            padding: 55px 45px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .login-heading {
            font-size: 29px;
            margin-bottom: 10px;
        }

        .login-subtitle {
            color: #94a3b8;
            font-size: 14px;
            line-height: 1.6;
            margin-bottom: 28px;
        }

        .message {
            padding: 12px;
            margin-bottom: 18px;
            border-radius: 8px;
            font-size: 13px;
            line-height: 1.5;
        }

        .error {
            background: #451a1a;
            color: #fecaca;
            border: 1px solid #7f1d1d;
        }

        .success {
            background: #123c2b;
            color: #bbf7d0;
            border: 1px solid #166534;
        }

        label {
            display: block;
            color: #dbe5f2;
            font-size: 13px;
            margin-bottom: 9px;
        }

        .input-group {
            margin-bottom: 21px;
        }

        input {
            width: 100%;
            padding: 14px;
            border: 1px solid #34465e;
            border-radius: 9px;
            outline: none;
            background: #0a1424;
            color: #f8fafc;
            font-size: 14px;
            transition: border-color 0.2s;
        }

        input:focus {
            border-color: #38bdf8;
            box-shadow: 0 0 0 3px rgba(56, 189, 248, 0.1);
        }

        input::placeholder {
            color: #64748b;
        }

        .login-button {
            width: 100%;
            padding: 14px;
            border: none;
            border-radius: 9px;
            background: #0284c7;
            color: white;
            font-size: 15px;
            font-weight: 700;
            cursor: pointer;
            transition: background 0.2s;
        }

        .login-button:hover {
            background: #0369a1;
        }

        .register-link {
            text-align: center;
            margin-top: 25px;
            font-size: 14px;
            color: #94a3b8;
        }

        a {
            color: #38bdf8;
            text-decoration: none;
            font-weight: 600;
        }

        a:hover {
            text-decoration: underline;
        }

        .security-note {
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #263449;
            color: #71849c;
            font-size: 12px;
            line-height: 1.7;
            text-align: center;
        }

        @media (max-width: 760px) {
            .container {
                max-width: 470px;
                grid-template-columns: 1fr;
            }

            .left-panel {
                padding: 30px;
            }

            .left-panel h1 {
                font-size: 28px;
            }

            .description {
                margin-bottom: 15px;
            }

            .feature {
                margin: 8px 0;
            }

            .right-panel {
                padding: 35px 30px;
            }
        }
    </style>
</head>

<body>

<div class="container">

    <section class="left-panel">

        <div class="brand">Sentinel<span>Mind</span></div>

        <h1>Intelligent Security.<br>
            <span>Smarter Protection.</span>
        </h1>

        <p class="description">
            Monitor security incidents, analyze potential threats,
            and manage your cyber security operations from one platform.
        </p>

        <div class="feature">
            <div class="feature-icon">&#128274;</div>
            <div>Secure User Authentication</div>
        </div>

        <div class="feature">
            <div class="feature-icon">&#128737;</div>
            <div>Threat and Incident Management</div>
        </div>

        <div class="feature">
            <div class="feature-icon">&#128202;</div>
            <div>Role-Based Access Control</div>
        </div>

    </section>

    <section class="right-panel">

        <h2 class="login-heading">Welcome Back</h2>

        <p class="login-subtitle">
            Sign in to access your SentinelMind security workspace.
        </p>

        <c:if test="${not empty param.registered}">
            <div class="message success">
                Registration submitted successfully. You can now sign in.
            </div>
        </c:if>

        <c:if test="${not empty error}">
            <div class="message error">
                <c:out value="${error}"/>
            </div>
        </c:if>

        <form action="${pageContext.request.contextPath}/login"
              method="post">

            <div class="input-group">
                <label for="email">Email Address</label>

                <input type="email"
                       id="email"
                       name="email"
                       placeholder="Enter your registered email"
                       maxlength="254"
                       autocomplete="username"
                       required>
            </div>

            <div class="input-group">
                <label for="password">Password</label>

                <input type="password"
                       id="password"
                       name="password"
                       placeholder="Enter your password"
                       autocomplete="current-password"
                       required>
            </div>

            <button type="submit" class="login-button">
                Sign In Securely
            </button>

        </form>

        <div class="register-link">
            Don't have an account?
            <a href="${pageContext.request.contextPath}/register">
                Create an account
            </a>
        </div>

        <div class="security-note">
            SentinelMind Cyber Security Platform<br>
            Authorized access only.
        </div>

    </section>

</div>

</body>
</html>