JSP views are stored under WEB-INF so they cannot be opened directly without the controller.
