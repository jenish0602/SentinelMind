<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!doctype html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Central Monitoring | SentinelMind</title><link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/app.css">
<style>
.monitor-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:14px;margin:20px 0}
.metric{padding:18px;border:1px solid #26364d;border-radius:14px;background:#101b2b}.metric span{display:block;color:#aab8ca}.metric strong{font-size:28px}
.table-wrap{overflow-x:auto;margin:18px 0}.monitor-table{width:100%;border-collapse:collapse;background:#101b2b}.monitor-table th,.monitor-table td{padding:11px;border-bottom:1px solid #26364d;text-align:left;white-space:nowrap}.status{font-weight:700}.ONLINE{color:#36d399}.IDLE_OR_STALE{color:#fbbf24}.OFFLINE{color:#94a3b8}
</style></head><body><main class="container">
<header class="topbar"><div><p class="eyebrow">SENTINELMIND ADMINISTRATION</p><h1>Central Monitoring</h1><p class="muted">Authorized overview of employee sessions and application activity.</p></div>
<a class="button" href="${pageContext.request.contextPath}/dashboard">Back to Dashboard</a></header>
<section class="monitor-grid">
<article class="metric"><span>Total Users</span><strong><c:out value="${summary.totalUsers}"/></strong></article>
<article class="metric"><span>Online (recent heartbeat)</span><strong><c:out value="${summary.onlineUsers}"/></strong></article>
<article class="metric"><span>Idle or Stale Sessions</span><strong><c:out value="${summary.staleUsers}"/></strong></article>
<article class="metric"><span>Logins Today</span><strong><c:out value="${summary.loginsToday}"/></strong></article>
<article class="metric"><span>Page Views Today</span><strong><c:out value="${summary.pageViewsToday}"/></strong></article>
</section>
<h2>Employee Presence and Active Sessions</h2><div class="table-wrap"><table class="monitor-table"><thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Login Time</th><th>Last Seen</th><th>IP Address</th></tr></thead><tbody>
<c:forEach var="u" items="${presence}"><tr><td><c:out value="${u.name}"/></td><td><c:out value="${u.email}"/></td><td><c:out value="${u.role}"/></td><td class="status ${u.status}"><c:out value="${u.status}"/></td><td><c:out value="${u.loginAt}"/></td><td><c:out value="${u.lastSeen}"/></td><td><c:out value="${u.ip}"/></td></tr></c:forEach>
</tbody></table></div>
<h2>Recent Page Activity</h2><div class="table-wrap"><table class="monitor-table"><thead><tr><th>Date and Time</th><th>User</th><th>Page</th><th>Action</th><th>IP</th></tr></thead><tbody>
<c:forEach var="a" items="${activity}"><tr><td><c:out value="${a.createdAt}"/></td><td><c:out value="${a.name}"/></td><td><c:out value="${a.page}"/></td><td><c:out value="${a.action}"/></td><td><c:out value="${a.ip}"/></td></tr></c:forEach>
</tbody></table></div>
<p class="muted">Presence is estimated from application heartbeats. A stale session is not proof of logout. Page views record requests, not guaranteed attention or productive work time.</p>
</main></body></html>