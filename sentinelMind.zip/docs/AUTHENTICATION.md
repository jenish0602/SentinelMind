# Authentication architecture

## Components

- `RegistrationServlet.java`: validates form inputs, hashes registration codes using SHA-256, looks up active available codes under SQL transaction with `FOR UPDATE`, stores passwords using BCrypt with cost 12, associates a role, increments usage count, commits.
- `LoginServlet.java`: loads user/role via prepared SQL statement, ensures ACTIVE status and BCrypt-hash format, checks password using BCrypt, invalidates old session, creates new session and calls `changeSessionId`.
- `AuthenticationFilter.java`: checks `userId` in the session for mapped protected routes.
- `AuthorizationFilter.java`: uses session `roleName` to enforce ADMIN/ANALYST/USER restrictions and selected write restrictions.
- `LogoutServlet.java`: closes monitoring record where possible and invalidates the user session.
- `ActivityTrackingFilter.java` and `MonitoringDAO.java`: track authenticated activity. Login stores a SHA-256 hash of the HTTP session ID for monitoring rather than a raw session identifier.

## Request flow

1. Browser submits email/password with POST `/login`.
2. Servlet verifies active user and BCrypt password hash.
3. Session receives `userId`, `fullName`, `email`, `roleId`, `roleName`.
4. Browser sends the servlet-session cookie on later requests; authentication and authorization filters enforce access.
5. POST/GET `/logout` invalidates the session.

## Credentials and tokens

This code uses Tomcat HTTP session cookies, **not JWT/OAuth tokens**. Registered passwords are BCrypt-hashed. Access codes are stored as SHA-256 hashes, so use long random codes because simple hashes can be guessed offline. JDBC supports `SM_DB_URL`, `SM_DB_USER`, `SM_DB_PASSWORD` environment variables, while Hibernate XML has separate connection configuration. Never commit actual live credentials, session cookies, or registration codes.

## Known limitations

Add CSRF protection, verify all routes are covered by access controls, configure HTTPS and secure session-cookie attributes, and implement login rate limits / failed-attempt accounting before production use.
