# SentinelMind

Intelligent Cyber Security Incident Detection and Threat Management System.

Java 21 Maven WAR project using Jakarta Servlet/JSP, JDBC, Hibernate, Spring and MySQL with Tomcat 10.1.

## Features

Role-based registration (ADMIN / ANALYST / USER), BCrypt login, servlet-session authentication, authorization filters, incident and threat management, tasks and assignments, reports, activity monitoring, audit logs and queued security scan requests (these do not perform actual network scans).

## Install

1. Install JDK 21, Maven, Tomcat 10.1 and MySQL.
2. Import the SQL from `database/` following its setup notes. Use a fresh local database or the appropriate migration, not both blindly.
3. Set environment variables `SM_DB_URL`, `SM_DB_USER`, `SM_DB_PASSWORD`; review separate Hibernate connection settings in `src/main/resources/hibernate.cfg.xml`.
4. Set up private random registration access codes locally. The public SQL templates do not contain usable demo codes.
5. Run `mvn clean package`, deploy `target/SentinelMind.war` to Tomcat, and open `/SentinelMind/` at your local Tomcat host/port.

## Authentication

See `docs/AUTHENTICATION.md`. Passwords use BCrypt, access codes are looked up as SHA-256 hashes, and logins use HTTP sessions (not JWT).

## Security notes

Educational project: audit endpoints, CSRF defense, cookie security and brute-force protections before production deployment. Do not commit secrets, user data or built artifacts.
